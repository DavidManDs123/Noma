from flask import Flask, request, Response
from twilio.twiml.voice_response import VoiceResponse

app = Flask(__name__)

@app.route("/voice", methods=["POST"])
def voice():
    resp = VoiceResponse()
    resp.say("שלום! הגעתם לקפה דניה. איך אפשר לעזור לכם היום?", language="he-IL", voice="Polly.Carmit")
    return Response(str(resp), mimetype="application/xml")

@app.route("/health", methods=["GET"])
def health():
    return "OK", 200

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=3000)
